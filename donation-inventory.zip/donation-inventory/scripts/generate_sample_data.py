"""Generate realistic sample data (CSV + JSON) relative to a reference date.
Usage: python scripts/generate_sample_data.py [YYYY-MM-DD]
"""
import csv, json, random, sys
from datetime import date, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from inventory_app.logic import Inventory          # noqa: E402
from inventory_app import storage                  # noqa: E402

today = date.fromisoformat(sys.argv[1]) if len(sys.argv) > 1 else date.today()
rnd = random.Random(79)
DONORS = ["Asha Foundation", "Green Leaf Stores", "City Rotary Club", "Ravi Kumar",
          "Sunrise School Alumni", "MedCare Pharmacy", "Anonymous", "Techno Club", "Lakshmi Traders"]
RECIPIENTS = ["Hope Shelter", "Govt School Medchal", "Old Age Home", "Flood Relief Camp", "Community Kitchen"]
CATALOG = {  # name, unit, (min,max) qty, shelf-life days or None
    "Food": [("Rice 25kg bags", "kg", (50, 400), 240), ("Wheat flour", "kg", (30, 300), 150),
             ("Canned beans", "pcs", (40, 300), 400), ("Cooking oil", "litre", (20, 150), 180),
             ("Biscuit packs", "pack", (50, 500), 60), ("Milk powder", "pack", (20, 120), 120)],
    "Clothing": [("Winter jackets", "pcs", (10, 80), None), ("School uniforms", "set", (20, 100), None),
                 ("Blankets", "pcs", (30, 150), None), ("Cotton t-shirts", "pcs", (40, 200), None)],
    "Medical": [("First-aid kits", "box", (5, 40), 500), ("Paracetamol strips", "pack", (30, 200), 90),
                ("Surgical masks", "box", (20, 100), 700), ("ORS sachets", "pack", (50, 300), 120)],
    "Hygiene": [("Soap bars", "pcs", (50, 400), None), ("Sanitary pads", "pack", (30, 200), None),
                ("Toothpaste", "pcs", (30, 200), 600)],
    "Education": [("Notebooks", "pcs", (50, 500), None), ("Geometry boxes", "set", (10, 80), None),
                  ("School bags", "pcs", (10, 60), None)],
    "Household": [("Steel plates", "set", (10, 60), None), ("Water bottles", "bottle", (20, 150), None)],
    "Electronics": [("Solar lamps", "pcs", (5, 40), None), ("Used laptops", "pcs", (1, 10), None)],
}
inv = Inventory()
rows = []
def add(name, cat, qty, unit, donor, rec, exp, mn):
    inv.add_item(name=name, category=cat, quantity=qty, unit=unit, donor=donor,
                 date_received=rec.isoformat(), expiry_date=exp.isoformat() if exp else None, min_stock=mn)

entries = [(cat, it) for cat, its in CATALOG.items() for it in its]
rnd.shuffle(entries)
for cat, (name, unit, (lo, hi), shelf) in entries[:32]:
    rec = today - timedelta(days=rnd.randint(3, 170))
    exp = rec + timedelta(days=shelf + rnd.randint(-30, 30)) if shelf else None
    add(name, cat, rnd.randint(lo, hi), unit, rnd.choice(DONORS), rec, exp, rnd.choice([5, 10, 20]))
# --- hand-crafted edge cases for the demo ---
add("Expired cough syrup", "Medical", 12, "bottle", "MedCare Pharmacy", today - timedelta(days=200), today - timedelta(days=5), 5)
add("Fresh bread loaves", "Food", 60, "pcs", "Green Leaf Stores", today - timedelta(days=2), today + timedelta(days=3), 10)
add("Insulin pens (cold chain)", "Medical", 8, "pcs", "MedCare Pharmacy", today - timedelta(days=20), today + timedelta(days=9), 5)
add("Single wheelchair", "Medical", 1, "pcs", "Ravi Kumar", today - timedelta(days=30), None, 0)           # boundary: qty 1
add("Bulk rice truckload", "Food", 12000, "kg", "Lakshmi Traders", today - timedelta(days=40), today + timedelta(days=200), 500)  # anomaly
add("Tiffin boxes", "Household", 15, "pcs", "Anonymous", today, None, 5)                                       # received today
add("Winter socks", "Clothing", 25, "pair", "City Rotary Club", today - timedelta(days=60), None, 30)          # starts below threshold
add("Pencil cases", "Education", 40, "pcs", "Sunrise School Alumni", today - timedelta(days=15), None, 5)

for it in inv.items:
    if it.expiry_date and it.expiry_date < today.isoformat():
        continue
    if it.name in ("Single wheelchair", "Tiffin boxes") or rnd.random() < 0.3:
        continue
    left = it.quantity
    for _ in range(rnd.randint(1, 3)):
        q = rnd.randint(1, max(1, int(left * 0.6)))
        if q > left:
            break
        when = max(date.fromisoformat(it.date_received), today - timedelta(days=rnd.randint(0, 60)))
        inv.distribute(it.id, q, rnd.choice(RECIPIENTS), when.isoformat(), today)
        left -= q
    if it.name == "Pencil cases":      # fully distributed edge case
        if left:
            inv.distribute(it.id, left, "Govt School Medchal", today.isoformat(), today)

data = ROOT / "data"
data.mkdir(exist_ok=True)
storage.save(inv, data / "sample_donations.json")
with open(data / "sample_donations.csv", "w", newline="", encoding="utf-8") as f:
    w = csv.writer(f)
    w.writerow(["name", "category", "quantity", "unit", "donor", "date_received", "expiry_date", "min_stock"])
    for i in inv.items:
        w.writerow([i.name, i.category, i.quantity, i.unit, i.donor, i.date_received, i.expiry_date or "", i.min_stock])
bad = [["name", "category", "quantity", "unit", "donor", "date_received", "expiry_date", "min_stock"],
       ["Rice bags", "Food", "100", "kg", "Asha Foundation", today.isoformat(), "", "10"],
       ["Rice bags", "Food", "-5", "kg", "Asha Foundation", today.isoformat(), "", "10"],
       ["", "Food", "20", "pcs", "X", today.isoformat(), "", ""],
       ["Laptop", "Gadgets", "2", "pcs", "Techno Club", today.isoformat(), "", ""],
       ["Pens", "Education", "abc", "pcs", "Techno Club", today.isoformat(), "", ""],
       ["Pens", "Education", "50", "pcs", "Techno Club", "31/02/2026", "", ""],
       ["Pens", "Education", "50", "pcs", "Techno Club", (today + timedelta(days=9)).isoformat(), "", ""],
       ["Milk", "Food", "30", "pack", "Dairy Co", "01/10/2026", "01/09/2026", ""],
       ["Shoes", "Clothing", "40", "pair", "Ravi Kumar", "15-10-2026", "", "8"]]
with open(data / "sample_import_with_errors.csv", "w", newline="", encoding="utf-8") as f:
    csv.writer(f).writerows(bad)
print(f"Generated {len(inv.items)} donations, {len(inv.distributions)} distributions (ref date {today}).")
