"""Pure validators (raise ValueError) + interactive prompt wrappers."""
import re
from datetime import date, datetime
from typing import Callable, Optional

CATEGORIES = ["Food", "Clothing", "Medical", "Hygiene", "Education",
              "Household", "Electronics", "Other"]
UNITS = ["pcs", "kg", "box", "pack", "bottle", "set", "pair", "litre"]
MAX_QTY = 100_000
DATE_FORMATS = ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y")
NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9 .,'&()/\-]{1,59}$")


class Cancelled(Exception):
    """Raised when the user types /cancel at any prompt."""


def clean_text(value) -> str:
    return re.sub(r"\s+", " ", str(value or "")).strip()


def validate_name(value, label="name") -> str:
    v = clean_text(value)
    if not NAME_RE.match(v):
        raise ValueError(f"{label} must be 2-60 chars (letters, digits, spaces, . , ' & ( ) / -)")
    return v


def validate_donor(value) -> str:
    v = clean_text(value)
    return "Anonymous" if not v else validate_name(v, "donor")


def validate_int(value, lo: int, hi: int, label="value") -> int:
    s = clean_text(value).replace(",", "")
    if not re.fullmatch(r"[+-]?\d+", s):
        raise ValueError(f"{label} must be a whole number")
    n = int(s)
    if not lo <= n <= hi:
        raise ValueError(f"{label} must be between {lo} and {hi}")
    return n


def validate_quantity(value) -> int:
    return validate_int(value, 1, MAX_QTY, "quantity")


def validate_category(value) -> str:
    v = clean_text(value)
    if v.isdigit() and 1 <= int(v) <= len(CATEGORIES):
        return CATEGORIES[int(v) - 1]
    for c in CATEGORIES:
        if c.lower() == v.lower():
            return c
    raise ValueError(f"category must be one of: {', '.join(CATEGORIES)}")


def validate_unit(value) -> str:
    v = clean_text(value).lower()
    if v in UNITS:
        return v
    raise ValueError(f"unit must be one of: {', '.join(UNITS)}")


def validate_date(value, allow_blank=False, not_future=False,
                  label="date") -> Optional[str]:
    v = clean_text(value)
    if not v:
        if allow_blank:
            return None
        raise ValueError(f"{label} is required")
    for fmt in DATE_FORMATS:
        try:
            d = datetime.strptime(v, fmt).date()
            break
        except ValueError:
            continue
    else:
        raise ValueError(f"{label} must look like YYYY-MM-DD or DD/MM/YYYY")
    if d.year < 2000:
        raise ValueError(f"{label} year is implausible")
    if not_future and d > date.today():
        raise ValueError(f"{label} cannot be in the future")
    return d.isoformat()


def validate_item_fields(raw: dict):
    """Validate a raw dict (CSV row / form). Returns (clean_dict, errors)."""
    clean, errors = {}, []

    def run(key, fn, *a, **k):
        try:
            clean[key] = fn(raw.get(key, ""), *a, **k)
        except ValueError as e:
            errors.append(str(e))

    run("name", validate_name)
    run("category", validate_category)
    run("quantity", validate_quantity)
    run("unit", validate_unit)
    run("donor", validate_donor)
    run("date_received", validate_date, not_future=True, label="date_received")
    run("expiry_date", validate_date, allow_blank=True, label="expiry_date")
    ms = clean_text(raw.get("min_stock", ""))
    if ms == "":
        clean["min_stock"] = 5
    else:
        run("min_stock", validate_int, 0, 10_000, "min_stock")
    if (clean.get("expiry_date") and clean.get("date_received")
            and clean["expiry_date"] < clean["date_received"]):
        errors.append("expiry_date is before date_received")
    return clean, errors


# ---------- interactive wrappers: loop until valid ----------
def ask(prompt: str, validator: Callable, default: Optional[str] = None):
    """Prompt until `validator` accepts the input. '/cancel' aborts."""
    suffix = f" [{default}]" if default is not None else ""
    while True:
        raw = input(f"{prompt}{suffix}: ")
        if raw.strip().lower() == "/cancel":
            raise Cancelled()
        if raw.strip() == "" and default is not None:
            raw = default
        try:
            return validator(raw)
        except ValueError as e:
            print(f"  \u2717 {e}. Try again (or type /cancel).")


def ask_yes_no(prompt: str, default="n") -> bool:
    def v(x):
        x = clean_text(x).lower()
        if x in ("y", "yes"):
            return True
        if x in ("n", "no"):
            return False
        raise ValueError("answer y or n")
    return ask(prompt + " (y/n)", v, default)
