"""JSON persistence with corruption recovery, atomic writes and audit log."""
import json
import os
import shutil
import tempfile
from datetime import datetime
from pathlib import Path

from .logic import Inventory
from .models import Distribution, Item

SCHEMA_VERSION = 1


def _from_dict(raw: dict) -> Inventory:
    if not isinstance(raw, dict) or raw.get("schema_version") != SCHEMA_VERSION:
        raise ValueError("unknown schema")
    items = [Item(**d) for d in raw["items"]]
    dists = [Distribution(**d) for d in raw["distributions"]]
    for i in items:
        if not isinstance(i.quantity, int) or i.quantity < 1:
            raise ValueError("bad quantity in file")
    ids = {i.id for i in items}
    if any(d.item_id not in ids for d in dists):
        raise ValueError("distribution refers to missing item")
    return Inventory(items, dists)


def to_dict(inv: Inventory) -> dict:
    return {"schema_version": SCHEMA_VERSION,
            "items": [i.to_dict() for i in inv.items],
            "distributions": [d.to_dict() for d in inv.distributions]}


def save(inv: Inventory, path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=path.parent, suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(to_dict(inv), f, indent=2)
        os.replace(tmp, path)          # atomic: never leaves a half-written file
    finally:
        if os.path.exists(tmp):
            os.remove(tmp)


def load(path):
    """Return (Inventory, notice_or_None). Never raises on bad/missing files."""
    path = Path(path)
    if not path.exists():
        inv = Inventory()
        save(inv, path)
        return inv, "No data file found - created a fresh inventory."
    try:
        return _from_dict(json.loads(path.read_text(encoding="utf-8"))), None
    except (json.JSONDecodeError, KeyError, TypeError, ValueError, UnicodeDecodeError) as e:
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        backup = path.with_name(f"{path.stem}.corrupt-{stamp}.json")
        shutil.copy2(path, backup)
        inv = Inventory()
        save(inv, path)
        return inv, (f"Data file was unreadable ({type(e).__name__}). "
                     f"Backed up to {backup.name} and started fresh.")


def log_event(data_path, action: str, detail: str) -> None:
    """Append-only plain-text audit trail next to the data file."""
    log = Path(data_path).with_name("audit.log")
    with open(log, "a", encoding="utf-8") as f:
        f.write(f"{datetime.now().isoformat(timespec='seconds')} | {action:<12} | {detail}\n")
