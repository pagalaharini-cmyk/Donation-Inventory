"""Menu-driven terminal interface."""
import os
import sys
from datetime import date
from pathlib import Path

from . import __version__, reports, storage
from .importer import import_csv
from .logic import Inventory
from .validation import (CATEGORIES, UNITS, Cancelled, ask, ask_yes_no, clean_text,
                         validate_category, validate_date, validate_donor, validate_int,
                         validate_name, validate_quantity, validate_unit)

if os.name == "nt":
    os.system("")  # enable ANSI escapes on Windows terminals

USE_COLOR = sys.stdout.isatty() and not os.environ.get("NO_COLOR")
COL = {"red": "31", "green": "32", "yellow": "33", "blue": "34", "cyan": "36", "bold": "1", "dim": "2"}
STATUS_COLOR = {"OK": "green", "LOW": "yellow", "EXPIRING": "yellow", "EXPIRED": "red", "OUT": "dim"}
PAGE = 10


def c(text, color):
    return f"\033[{COL[color]}m{text}\033[0m" if USE_COLOR else str(text)


BANNER = r"""
  ____                    _   _               ___                      _
 |  _ \  ___  _ __   __ _| |_(_) ___  _ __   |_ _|_ ____   _____ _ __ | |_ ___  _ __ _   _
 | | | |/ _ \| '_ \ / _` | __| |/ _ \| '_ \   | || '_ \ \ / / _ \ '_ \| __/ _ \| '__| | | |
 | |_| | (_) | | | | (_| | |_| | (_) | | | |  | || | | \ V /  __/ | | | || (_) | |  | |_| |
 |____/ \___/|_| |_|\__,_|\__|_|\___/|_| |_| |___|_| |_|\_/ \___|_| |_|\__\___/|_|   \__, |
                                                                                    |___/
"""

MENU = [("1", "Record new donation"), ("2", "Record distribution"),
        ("3", "View inventory"), ("4", "Search / filter"),
        ("5", "Summary dashboard"), ("6", "Warnings"),
        ("7", "Export reports"), ("8", "Bulk import CSV"),
        ("9", "Load sample data"), ("0", "Save & exit")]


class App:
    def __init__(self, data_path: Path, root: Path):
        self.path = Path(data_path)
        self.root = Path(root)
        self.inv, notice = storage.load(self.path)
        self.notice = notice

    # ---------- helpers ----------
    def save(self, action, detail):
        storage.save(self.inv, self.path)
        storage.log_event(self.path, action, detail)

    def table(self, items, title="Inventory"):
        if not items:
            print(c("  (no matching records)", "dim"))
            return
        hdr = f"{'ID':>4} {'Name':<26} {'Category':<11} {'Recv':>6} {'Dist':>6} {'Stock':>6} {'Unit':<6} {'Expiry':<10} {'Status':<8}"
        total = len(items)
        for start in range(0, total, PAGE):
            print(c(f"\n{title}  (rows {start + 1}-{min(start + PAGE, total)} of {total})", "bold"))
            print(c(hdr, "cyan"))
            print("-" * len(hdr))
            for i in items[start:start + PAGE]:
                st = self.inv.status(i)
                name = i.name if len(i.name) <= 26 else i.name[:25] + "\u2026"
                row = (f"{i.id:>4} {name:<26} {i.category:<11} {i.quantity:>6} "
                       f"{self.inv.distributed(i.id):>6} {self.inv.stock(i.id):>6} "
                       f"{i.unit:<6} {(i.expiry_date or '-'):<10} ")
                print(row + c(f"{st:<8}", STATUS_COLOR[st]))
            if start + PAGE < total:
                if input(c("-- Enter for next page, q to stop -- ", "dim")).strip().lower() == "q":
                    break

    # ---------- actions ----------
    def add_donation(self):
        print(c("\nRecord new donation  (type /cancel to abort)", "bold"))
        name = ask("Item name", validate_name)
        print("Categories: " + ", ".join(f"{n}={cat}" for n, cat in enumerate(CATEGORIES, 1)))
        cat = ask("Category (name or number)", validate_category)
        qty = ask("Quantity received", validate_quantity)
        unit = ask(f"Unit ({'/'.join(UNITS)})", validate_unit, "pcs")
        donor = ask("Donor (blank = Anonymous)", validate_donor, "")
        today = date.today().isoformat()
        rec = ask("Date received", lambda v: validate_date(v, not_future=True, label="date"), today)
        exp = ask("Expiry date (blank = none)", lambda v: validate_date(v, allow_blank=True, label="expiry"), "")
        if exp and exp < rec:
            print(c("  \u2717 Expiry is before received date - entry discarded.", "red"))
            return
        mn = ask("Low-stock threshold", lambda v: validate_int(v, 0, 10_000, "threshold"), "5")
        item = self.inv.add_item(name=name, category=cat, quantity=qty, unit=unit, donor=donor,
                                 date_received=rec, expiry_date=exp, min_stock=mn)
        self.save("ADD", f"#{item.id} {item.name} x{item.quantity} {item.unit} from {item.donor}")
        print(c(f"  \u2713 Saved as record #{item.id}.", "green"))

    def distribute(self):
        print(c("\nRecord distribution  (type /cancel to abort)", "bold"))
        avail = [i for i in self.inv.items if self.inv.stock(i.id) > 0]
        if not avail:
            print(c("  Nothing in stock to distribute.", "yellow"))
            return
        def vid(v):
            n = validate_int(v, 1, 10**9, "id")
            if n not in {i.id for i in avail}:
                raise ValueError("no in-stock record with that id (use View inventory)")
            return n
        iid = ask("Item id", vid)
        item = self.inv.get_item(iid)
        print(f"  {item.name}: {self.inv.stock(iid)} {item.unit} in stock")
        qty = ask("Quantity to distribute", validate_quantity)
        who = ask("Recipient", lambda v: validate_name(v, "recipient"))
        when = ask("Date", lambda v: validate_date(v, not_future=True, label="date"), date.today().isoformat())
        try:
            d = self.inv.distribute(iid, qty, who, when)
        except ValueError as e:
            print(c(f"  \u2717 {e}", "red"))
            return
        self.save("DISTRIBUTE", f"#{iid} {item.name} x{qty} to {who}")
        print(c(f"  \u2713 Distribution #{d.id} recorded. Remaining: {self.inv.stock(iid)} {item.unit}", "green"))

    def view(self):
        self.table(self.inv.items, "All inventory")

    def search(self):
        print(c("\nSearch / filter  (blank = no filter)", "bold"))
        kw = ask("Keyword (name/donor/category)", clean_text, "")
        cat = ask("Category", lambda v: validate_category(v) if clean_text(v) else None, "")
        def vstatus(v):
            v = clean_text(v).upper()
            if v and v not in STATUS_COLOR:
                raise ValueError("pick OK, LOW, EXPIRING, EXPIRED or OUT")
            return v or None
        st = ask("Status (OK/LOW/EXPIRING/EXPIRED/OUT)", vstatus, "")
        self.table(self.inv.search(kw, cat, st), "Search results")

    def summary(self):
        print("\n" + reports.render_text(reports.build_summary(self.inv)))

    def warnings(self):
        ws = self.inv.warnings()
        if not ws:
            print(c("\n  \u2713 No warnings.", "green"))
            return
        print(c(f"\n{len(ws)} warning(s):", "bold"))
        color = {"CRITICAL": "red", "WARN": "yellow", "INFO": "blue"}
        for lv, it, msg in ws:
            print(f"  {c(f'[{lv}]', color[lv]):<18} #{it.id} {it.name}: {msg}")

    def export(self):
        files = reports.export_all(self.inv, self.root / "reports")
        storage.log_event(self.path, "EXPORT", ", ".join(f.name for f in files))
        print(c("\n  \u2713 Exported:", "green"))
        for f in files:
            print(f"    {f}")
        if not any(f.suffix == ".png" for f in files):
            print(c("    (install matplotlib to also get a PNG chart)", "dim"))

    def bulk_import(self):
        default = str(self.root / "data" / "sample_donations.csv")
        p = ask("CSV path", lambda v: clean_text(v).strip('"'), default)
        try:
            added, errs, log = import_csv(self.inv, p, self.root / "reports")
        except ValueError as e:
            print(c(f"  \u2717 {e}", "red"))
            return
        if added:
            self.save("IMPORT", f"{added} rows from {Path(p).name}")
        print(c(f"  \u2713 {added} row(s) imported, {len(errs)} rejected.", "green" if not errs else "yellow"))
        for n, e in errs[:8]:
            print(c(f"    row {n}: {'; '.join(e)}", "red"))
        if len(errs) > 8:
            print(c(f"    ... and {len(errs) - 8} more", "dim"))
        if log:
            print(f"  Full error log: {log}")

    def load_sample(self):
        sample = self.root / "data" / "sample_donations.json"
        if not sample.exists():
            print(c("  Sample file missing - run scripts/generate_sample_data.py", "red"))
            return
        if self.inv.items and not ask_yes_no("This REPLACES current data. Continue?", "n"):
            return
        inv, notice = storage.load(sample)
        self.inv = inv
        self.save("SEED", f"loaded sample ({len(inv.items)} items)")
        print(c(f"  \u2713 Loaded {len(inv.items)} donations and {len(inv.distributions)} distributions.", "green"))

    # ---------- main loop ----------
    def run(self):
        print(c(BANNER, "cyan"))
        print(c(f"  Safety & Community | FutureReady Hack #79 | v{__version__}", "dim"))
        if self.notice:
            print(c(f"\n  ! {self.notice}", "yellow"))
        n_warn = self.inv.warnings()
        if n_warn:
            print(c(f"\n  ! {len(n_warn)} active warning(s) - see option 6", "yellow"))
        actions = {"1": self.add_donation, "2": self.distribute, "3": self.view,
                   "4": self.search, "5": self.summary, "6": self.warnings,
                   "7": self.export, "8": self.bulk_import, "9": self.load_sample}
        while True:
            print(c("\n==== MAIN MENU ====", "bold"))
            for k, label in MENU:
                print(f"  {c(k, 'cyan')}. {label}")
            try:
                choice = input("Choose an option: ").strip()
                if choice == "0":
                    storage.save(self.inv, self.path)
                    print("Data saved. Goodbye!")
                    return
                fn = actions.get(choice)
                if fn is None:
                    print(c("  Please enter a number from the menu.", "red"))
                    continue
                fn()
            except Cancelled:
                print(c("  Cancelled.", "yellow"))
            except (KeyboardInterrupt, EOFError):
                storage.save(self.inv, self.path)
                print("\nInterrupted - data saved. Goodbye!")
                return
