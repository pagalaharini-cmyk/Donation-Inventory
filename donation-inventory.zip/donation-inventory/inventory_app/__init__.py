"""Donation Item Inventory - FutureReady Hack prototype."""
__version__ = "0.1.0"
