"""Business logic: stock tracking, distribution rules, search, warnings."""
from datetime import date, datetime, timedelta
from typing import List, Optional

from .models import Distribution, Item

EXPIRY_WARN_DAYS = 14
LARGE_DONATION = 5_000   # anomaly threshold


def _d(s: Optional[str]) -> Optional[date]:
    return datetime.strptime(s, "%Y-%m-%d").date() if s else None


class Inventory:
    def __init__(self, items=None, distributions=None):
        self.items: List[Item] = list(items or [])
        self.distributions: List[Distribution] = list(distributions or [])
        self._next_item = max((i.id for i in self.items), default=0) + 1
        self._next_dist = max((d.id for d in self.distributions), default=0) + 1

    # ---- lookups ----
    def get_item(self, item_id: int) -> Optional[Item]:
        return next((i for i in self.items if i.id == item_id), None)

    def distributed(self, item_id: int) -> int:
        return sum(d.quantity for d in self.distributions if d.item_id == item_id)

    def stock(self, item_id: int) -> int:
        item = self.get_item(item_id)
        return (item.quantity - self.distributed(item_id)) if item else 0

    # ---- mutations ----
    def add_item(self, **f) -> Item:
        item = Item(id=self._next_item, **f)
        self._next_item += 1
        self.items.append(item)
        return item

    def distribute(self, item_id: int, qty: int, recipient: str,
                   when: str, today: Optional[date] = None) -> Distribution:
        today = today or date.today()
        item = self.get_item(item_id)
        if item is None:
            raise ValueError(f"no item with id {item_id}")
        if item.expiry_date and _d(item.expiry_date) < today:
            raise ValueError(f"'{item.name}' expired on {item.expiry_date}; cannot distribute")
        avail = self.stock(item_id)
        if qty > avail:
            raise ValueError(f"only {avail} {item.unit} in stock")
        if when < item.date_received:
            raise ValueError("distribution date is before the item was received")
        dist = Distribution(self._next_dist, item_id, qty, recipient, when)
        self._next_dist += 1
        self.distributions.append(dist)
        return dist

    # ---- status / search ----
    def status(self, item: Item, today: Optional[date] = None) -> str:
        today = today or date.today()
        stock = self.stock(item.id)
        if item.expiry_date and stock > 0:
            if _d(item.expiry_date) < today:
                return "EXPIRED"
        if stock == 0:
            return "OUT"
        if stock <= item.min_stock:
            return "LOW"
        if item.expiry_date and _d(item.expiry_date) <= today + timedelta(days=EXPIRY_WARN_DAYS):
            return "EXPIRING"
        return "OK"

    def search(self, keyword="", category=None, status=None,
               today: Optional[date] = None) -> List[Item]:
        kw = keyword.lower().strip()
        out = []
        for i in self.items:
            if category and i.category != category:
                continue
            if kw and kw not in f"{i.name} {i.donor} {i.category}".lower():
                continue
            if status and self.status(i, today) != status:
                continue
            out.append(i)
        return out

    # ---- warnings ----
    def warnings(self, today: Optional[date] = None):
        """Return list of (level, item, message). Levels: CRITICAL, WARN, INFO."""
        today = today or date.today()
        out = []
        for i in self.items:
            stock = self.stock(i.id)
            if i.expiry_date and stock > 0:
                exp = _d(i.expiry_date)
                if exp < today:
                    out.append(("CRITICAL", i, f"EXPIRED {(today - exp).days}d ago with {stock} {i.unit} left"))
                elif exp <= today + timedelta(days=EXPIRY_WARN_DAYS):
                    out.append(("WARN", i, f"expires in {(exp - today).days}d with {stock} {i.unit} left"))
            if 0 < stock <= i.min_stock:
                out.append(("WARN", i, f"low stock: {stock} {i.unit} (min {i.min_stock})"))
            if stock == 0 and self.distributed(i.id) > 0:
                out.append(("INFO", i, "fully distributed (out of stock)"))
            if i.quantity >= LARGE_DONATION:
                out.append(("INFO", i, f"unusually large donation ({i.quantity} {i.unit}) - verify entry"))
        order = {"CRITICAL": 0, "WARN": 1, "INFO": 2}
        out.sort(key=lambda w: (order[w[0]], w[1].id))
        return out
