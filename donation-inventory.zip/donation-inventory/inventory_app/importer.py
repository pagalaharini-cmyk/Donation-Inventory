"""Bulk CSV import with row-by-row validation and an error log."""
import csv
from datetime import datetime
from pathlib import Path

from .logic import Inventory
from .validation import validate_item_fields

REQUIRED = {"name", "category", "quantity", "unit", "date_received"}


def import_csv(inv: Inventory, csv_path, error_log_dir):
    """Returns (added, errors, log_path). Raises ValueError for unusable files."""
    csv_path = Path(csv_path)
    if not csv_path.is_file():
        raise ValueError(f"file not found: {csv_path}")
    added, errors = 0, []
    try:
        with open(csv_path, newline="", encoding="utf-8-sig") as f:
            reader = csv.DictReader(f)
            headers = {h.strip().lower() for h in (reader.fieldnames or [])}
            missing = REQUIRED - headers
            if missing:
                raise ValueError(f"missing required column(s): {', '.join(sorted(missing))}")
            for n, row in enumerate(reader, start=2):      # row 1 = header
                row = {(k or "").strip().lower(): v for k, v in row.items()}
                clean, errs = validate_item_fields(row)
                if errs:
                    errors.append((n, errs))
                    continue
                inv.add_item(**clean)
                added += 1
    except UnicodeDecodeError:
        raise ValueError("file is not valid UTF-8 text")
    log_path = None
    if errors:
        Path(error_log_dir).mkdir(parents=True, exist_ok=True)
        log_path = Path(error_log_dir) / f"import_errors_{datetime.now():%Y%m%d_%H%M%S}.log"
        with open(log_path, "w", encoding="utf-8") as f:
            f.write(f"Import of {csv_path.name}: {added} added, {len(errors)} rejected\n")
            for n, errs in errors:
                f.write(f"row {n}: " + "; ".join(errs) + "\n")
    return added, errors, log_path
