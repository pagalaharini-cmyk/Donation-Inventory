"""Summary analytics + export (text, Markdown, CSV, optional chart)."""
import csv
from collections import defaultdict
from datetime import date, datetime
from pathlib import Path

from .logic import Inventory
from .validation import CATEGORIES


def build_summary(inv: Inventory, today: date = None) -> dict:
    today = today or date.today()
    recv = sum(i.quantity for i in inv.items)
    dist = sum(d.quantity for d in inv.distributions)
    cats = []
    for c in CATEGORIES:
        its = [i for i in inv.items if i.category == c]
        if not its:
            continue
        r = sum(i.quantity for i in its)
        d = sum(inv.distributed(i.id) for i in its)
        cats.append({"category": c, "records": len(its), "received": r,
                     "distributed": d, "stock": r - d})
    donors = defaultdict(int)
    monthly = defaultdict(int)
    for i in inv.items:
        donors[i.donor] += i.quantity
        monthly[i.date_received[:7]] += i.quantity
    recipients = defaultdict(int)
    for d in inv.distributions:
        recipients[d.recipient] += d.quantity
    status = defaultdict(int)
    for i in inv.items:
        status[inv.status(i, today)] += 1
    return {
        "generated": datetime.now().strftime("%Y-%m-%d %H:%M"),
        "records": len(inv.items),
        "distributions": len(inv.distributions),
        "total_received": recv,
        "total_distributed": dist,
        "in_stock": recv - dist,
        "distribution_rate": (dist / recv * 100) if recv else 0.0,
        "avg_donation": (recv / len(inv.items)) if inv.items else 0.0,
        "avg_distribution": (dist / len(inv.distributions)) if inv.distributions else 0.0,
        "categories": cats,
        "top_donors": sorted(donors.items(), key=lambda x: -x[1])[:5],
        "top_recipients": sorted(recipients.items(), key=lambda x: -x[1])[:5],
        "monthly": sorted(monthly.items())[-6:],
        "status": dict(status),
        "warning_count": len(inv.warnings(today)),
    }


def bar(value, max_value, width=28, char="#") -> str:
    n = int(round(width * value / max_value)) if max_value else 0
    return char * n


def render_text(s: dict) -> str:
    L = ["=" * 64, " DONATION ITEM INVENTORY - EXECUTIVE SUMMARY",
         f" Generated: {s['generated']}", "=" * 64,
         f" Donation records     : {s['records']}",
         f" Distribution records : {s['distributions']}",
         f" Units received       : {s['total_received']:,}",
         f" Units distributed    : {s['total_distributed']:,}",
         f" Units in stock       : {s['in_stock']:,}",
         f" Distribution rate    : {s['distribution_rate']:.1f}%",
         f" Avg donation size    : {s['avg_donation']:.1f}",
         f" Avg distribution size: {s['avg_distribution']:.1f}",
         f" Active warnings      : {s['warning_count']}", "",
         " BY CATEGORY", f" {'Category':<12}{'Recs':>5}{'Recv':>8}{'Dist':>8}{'Stock':>8}",
         " " + "-" * 41]
    for c in s["categories"]:
        L.append(f" {c['category']:<12}{c['records']:>5}{c['received']:>8}{c['distributed']:>8}{c['stock']:>8}")
    L += ["", " ITEM STATUS: " + ", ".join(f"{k}={v}" for k, v in sorted(s["status"].items())), ""]
    mx = max([v for _, v in s["monthly"]] or [0])
    L.append(" DONATION TREND (units received per month)")
    for m, v in s["monthly"]:
        L.append(f" {m}  {bar(v, mx):<28} {v:,}")
    L += ["", " TOP DONORS"] + [f"  {n:<28}{v:>8,}" for n, v in s["top_donors"]]
    L += ["", " TOP RECIPIENTS"] + [f"  {n:<28}{v:>8,}" for n, v in s["top_recipients"]]
    return "\n".join(L) + "\n"


def render_markdown(s: dict) -> str:
    L = ["# Donation Item Inventory - Executive Summary", f"_Generated {s['generated']}_", "",
         "| Metric | Value |", "|---|---|",
         f"| Donation records | {s['records']} |",
         f"| Distribution records | {s['distributions']} |",
         f"| Units received | {s['total_received']:,} |",
         f"| Units distributed | {s['total_distributed']:,} |",
         f"| Units in stock | {s['in_stock']:,} |",
         f"| Distribution rate | {s['distribution_rate']:.1f}% |",
         f"| Avg donation size | {s['avg_donation']:.1f} |",
         f"| Active warnings | {s['warning_count']} |", "",
         "## By category", "| Category | Records | Received | Distributed | In stock |",
         "|---|---:|---:|---:|---:|"]
    for c in s["categories"]:
        L.append(f"| {c['category']} | {c['records']} | {c['received']} | {c['distributed']} | {c['stock']} |")
    L += ["", "## Monthly trend", "| Month | Units received |", "|---|---:|"]
    L += [f"| {m} | {v} |" for m, v in s["monthly"]]
    L += ["", "## Top donors"] + [f"{k}. {n} - {v:,} units" for k, (n, v) in enumerate(s["top_donors"], 1)]
    L += ["", "## Top recipients"] + [f"{k}. {n} - {v:,} units" for k, (n, v) in enumerate(s["top_recipients"], 1)]
    return "\n".join(L) + "\n"


def export_inventory_csv(inv: Inventory, path, today: date = None) -> None:
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["id", "name", "category", "received", "distributed", "stock",
                    "unit", "donor", "date_received", "expiry_date", "min_stock", "status"])
        for i in inv.items:
            w.writerow([i.id, i.name, i.category, i.quantity, inv.distributed(i.id),
                        inv.stock(i.id), i.unit, i.donor, i.date_received,
                        i.expiry_date or "", i.min_stock, inv.status(i, today)])


def export_chart(s: dict, path):
    """Optional Matplotlib chart; returns path or None if matplotlib missing."""
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        return None
    cats = s["categories"]
    x = range(len(cats))
    fig, ax = plt.subplots(figsize=(8, 4.5))
    ax.bar([i - 0.2 for i in x], [c["received"] for c in cats], 0.4, label="Received")
    ax.bar([i + 0.2 for i in x], [c["distributed"] for c in cats], 0.4, label="Distributed")
    ax.set_xticks(list(x))
    ax.set_xticklabels([c["category"] for c in cats], rotation=30)
    ax.set_title("Donations received vs distributed by category")
    ax.legend()
    fig.tight_layout()
    fig.savefig(path, dpi=120)
    plt.close(fig)
    return path


def export_all(inv: Inventory, out_dir, today: date = None) -> list:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    s = build_summary(inv, today)
    files = []
    p = out / f"summary_{stamp}.md"; p.write_text(render_markdown(s), encoding="utf-8"); files.append(p)
    p = out / f"audit_{stamp}.txt"
    warn_lines = [f"[{lv}] #{it.id} {it.name}: {msg}" for lv, it, msg in inv.warnings(today)]
    p.write_text(render_text(s) + "\nWARNINGS\n" + ("\n".join(warn_lines) or "none") + "\n", encoding="utf-8"); files.append(p)
    p = out / f"inventory_{stamp}.csv"; export_inventory_csv(inv, p, today); files.append(p)
    chart = export_chart(s, out / f"chart_{stamp}.png")
    if chart:
        files.append(chart)
    return files
