"""Core data structures."""
from dataclasses import dataclass, asdict
from typing import Optional


@dataclass
class Item:
    """One donation record (a 'batch' of an item received from a donor)."""
    id: int
    name: str
    category: str
    quantity: int            # units received
    unit: str
    donor: str
    date_received: str       # ISO yyyy-mm-dd
    expiry_date: Optional[str] = None
    min_stock: int = 5       # low-stock threshold

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class Distribution:
    """Units of a donation batch handed out to a recipient."""
    id: int
    item_id: int
    quantity: int
    recipient: str
    date: str

    def to_dict(self) -> dict:
        return asdict(self)
