"""Entry point:  python main.py [--data PATH] [--demo]"""
import argparse
from pathlib import Path

from inventory_app.ui import App

ROOT = Path(__file__).resolve().parent


def main():
    ap = argparse.ArgumentParser(description="Donation Item Inventory")
    ap.add_argument("--data", default=str(ROOT / "data" / "donations.json"),
                    help="path to the JSON data file")
    args = ap.parse_args()
    App(Path(args.data), ROOT).run()


if __name__ == "__main__":
    main()
