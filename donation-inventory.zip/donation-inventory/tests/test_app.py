import json, os, sys, tempfile, unittest
from datetime import date
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from inventory_app import storage, validation as v          # noqa: E402
from inventory_app.importer import import_csv                # noqa: E402
from inventory_app.logic import Inventory                    # noqa: E402
from inventory_app.reports import build_summary              # noqa: E402

TODAY = date(2026, 11, 23)


def mk(inv, **o):
    f = dict(name="Rice", category="Food", quantity=100, unit="kg", donor="A",
             date_received="2026-11-01", expiry_date=None, min_stock=5)
    f.update(o)
    return inv.add_item(**f)


class ValidationTests(unittest.TestCase):
    def test_quantity(self):
        self.assertEqual(v.validate_quantity(" 1,200 "), 1200)
        for bad in ("", "abc", "0", "-3", "2.5", "100001"):
            with self.assertRaises(ValueError):
                v.validate_quantity(bad)

    def test_dates(self):
        self.assertEqual(v.validate_date("23/11/2026"), "2026-11-23")
        for bad in ("31/02/2026", "yesterday", "", "1999-01-01"):
            with self.assertRaises(ValueError):
                v.validate_date(bad)
        self.assertIsNone(v.validate_date("", allow_blank=True))

    def test_category_by_number(self):
        self.assertEqual(v.validate_category("1"), "Food")
        self.assertEqual(v.validate_category("medical"), "Medical")


class LogicTests(unittest.TestCase):
    def test_distribution_and_stock(self):
        inv = Inventory(); it = mk(inv)
        inv.distribute(it.id, 40, "Shelter", "2026-11-05", TODAY)
        self.assertEqual(inv.stock(it.id), 60)
        with self.assertRaises(ValueError):
            inv.distribute(it.id, 61, "Shelter", "2026-11-06", TODAY)   # oversell

    def test_expired_blocked_and_warned(self):
        inv = Inventory(); it = mk(inv, expiry_date="2026-11-01")
        with self.assertRaises(ValueError):
            inv.distribute(it.id, 1, "X", "2026-11-02", TODAY)
        self.assertEqual(inv.status(it, TODAY), "EXPIRED")
        self.assertEqual(inv.warnings(TODAY)[0][0], "CRITICAL")

    def test_low_and_search(self):
        inv = Inventory(); it = mk(inv, quantity=10, min_stock=5)
        inv.distribute(it.id, 6, "X", "2026-11-02", TODAY)
        self.assertEqual(inv.status(it, TODAY), "LOW")
        self.assertEqual(len(inv.search("ric")), 1)
        self.assertEqual(len(inv.search(category="Medical")), 0)

    def test_summary(self):
        inv = Inventory(); it = mk(inv); inv.distribute(it.id, 25, "X", "2026-11-02", TODAY)
        s = build_summary(inv, TODAY)
        self.assertEqual((s["total_received"], s["total_distributed"], s["in_stock"]), (100, 25, 75))
        self.assertAlmostEqual(s["distribution_rate"], 25.0)


class StorageTests(unittest.TestCase):
    def test_roundtrip_and_corruption(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "x.json"
            inv, note = storage.load(p)                 # missing -> created
            self.assertIsNotNone(note)
            mk(inv); storage.save(inv, p)
            self.assertEqual(len(storage.load(p)[0].items), 1)
            p.write_text("{not json", encoding="utf-8")  # corrupt
            inv2, note2 = storage.load(p)
            self.assertEqual(len(inv2.items), 0)
            self.assertIn("Backed up", note2)
            self.assertTrue(list(Path(d).glob("*.corrupt-*.json")))

    def test_import_with_errors(self):
        root = Path(__file__).resolve().parent.parent
        with tempfile.TemporaryDirectory() as d:
            inv = Inventory()
            added, errs, log = import_csv(inv, root / "data" / "sample_import_with_errors.csv", d)
            self.assertEqual(added, 2)
            self.assertEqual(len(errs), 7)
            self.assertTrue(log.exists())


if __name__ == "__main__":
    unittest.main()
